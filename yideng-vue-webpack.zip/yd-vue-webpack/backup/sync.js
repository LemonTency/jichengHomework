//同步的javascript的会被打包进同同一个文件
const sync = "我是同步的文件🐻";
export default sync;

//异步的javascript的会被打包进同同一个文件
const asyncdata = "我是异步的文件🐩";
export default asyncdata;
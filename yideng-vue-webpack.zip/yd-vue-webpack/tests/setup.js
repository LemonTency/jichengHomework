require('jsdom-global')()
window.Date = Date;